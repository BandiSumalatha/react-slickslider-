import { BrowserRouter, Route, Routes,  } from "react-router-dom";
import Layout from "./components/layout/Layout";
import Login from "./pages/login/Login";
import SignUp from "./pages/signup/SignUp";
import Dashboard from "./pages/dashboard/Dashboard";
import Profile from "./pages/profile/Profile";
import Setting from "./pages/settings/Setting";
import { useAuth } from './hooks/AuthProvider';

function App() {
  return (
    <BrowserRouter>
      <Routes>
             <Route path="/" element={<Login />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/dashboard" element={<Layout><Dashboard /></Layout>} />
        <Route path="/profile" element={<Layout><Profile /></Layout>} />
        <Route path="/settings" element={<Layout><Setting /></Layout>} />
      </Routes>
    </BrowserRouter>
  );
}




export default App;