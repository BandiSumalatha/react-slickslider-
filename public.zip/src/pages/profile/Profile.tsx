import { useEffect, useState } from 'react';
import styled from 'styled-components';
import userimage from "../../assets/profile.png";
import Skeleton from '@mui/material/Skeleton';
import { Box } from "@mui/material";
import { useAuth } from '../../hooks/AuthProvider';

// Styled components for Profile
const ProfileContainer = styled.div`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: center;
`;

const ProfileImage = styled.div`
  flex-shrink: 0;
  margin-right: 20px;
  width: 50%;   
  text-align: center; /* Center the content horizontally */
`;

const ProfileDetails = styled.div`
  flex-grow: 1;
  width: 50%; /* Take up half the space */
`;

const Profile = () => {
  const { userData } = useAuth();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const delay = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    return () => clearTimeout(delay);
  }, []);

  if (!userData) {
    return <Box className="profile-container no-user-data">No user data found</Box>;
  }

  return (
    <ProfileContainer>
      <ProfileImage>
        {isLoading ? (
          <Skeleton variant="circle" width={200} height={200} animation="wave" />
        ) : (
          <img src={userimage} alt="Profile" style={{ width: 250, height: 250, borderRadius: '50%' }} />
        )}
      </ProfileImage>
      <ProfileDetails>
        <h2 className="profile-heading">Welcome, {userData.user.fname} {userData.user.lname}!</h2>
        <p>Email: {userData.user.email}</p>
        <p>Phone Number: {userData.user.phonenumber}</p>
        <p>Age: {userData.user.age}</p>
        <p>Address: {userData.user.address}</p>
      </ProfileDetails>
    </ProfileContainer>
  );
};

export default Profile;
