
const Setting = () => {
  return (
    <div>Setting</div>
  )
}

export default Setting