import { styled } from '@mui/system';
import { FormGroup } from '@mui/material';
import {Typography,Button,Grid} from '@mui/material';

export const StyledFormGroup = styled(FormGroup)({
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center',
});
export const FormContainer = styled(Grid)({

  border: '1px solid #ccc', 
  borderRadius: '15px', 
  boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.1)',
  padding:'20px',
  position: "absolute",
  top: "50%",
  left:" 50%",
  transform: "translate(-50%, -50%)"
});

export const StyledTitle=styled((Typography))({
fontFamily:'sans-serif',
fontSize:'30px',
fontWeight:'bold',
textAlign:'center',
margin:'auto',
paddingBottom:'20px',
color:'#A020F0'
})

export const labelStyle=styled((Typography))({
  lineHeight:'10px',
  margin:'50px'
});

export const CustomButton = styled(Button)(({ type }) => ({
  backgroundColor: type === 'submit' ? 'green' : 'orange',
  marginRight:type==='submit'? '50px':'0px',
  color: 'white',
  padding: '10px 20px',
  '&:hover': {
    backgroundColor: type === 'submit' ? 'darkgreen' : 'darkorange', 
  },
}));

export const ButtonContainer=styled(Grid)({
  display:'flex',
  alignItems:'center',
  justifyContent:'center',
  margin:'auto',
 
})