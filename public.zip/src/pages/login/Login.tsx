// Login.js
import  { useState } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import { TextField, Link, Grid, Modal, Typography, Box } from '@mui/material';
import OTPInput from '../otp/Otp';
import { FormContainer, TitleBox, InnerContainer, ButtonComponent } from './loginStyles';
import { useAuth } from '../../hooks/AuthProvider';

const Login = () => {
  const { setUserData } = useAuth();
  
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [showModal, setShowModal] = useState(false);

  const handleChange = (event:any) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const validateEmail = (email:any) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleSubmit = async (event:any) => {
    event.preventDefault();
    try {
      const response = await fetch('http://localhost:3000/api/users/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
      if (!response.ok) {
        throw new Error('Failed to login');
      }
      const data = await response.json();
      localStorage.setItem('userData', JSON.stringify(data));
      setUserData(data);
      setShowModal(true);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const closeModal = () => {
    setShowModal(false);
  };

  return (
    <FormContainer  maxWidth="xs">
      <TitleBox>
        <Typography component="h1" variant="h5" style={{ textAlign: 'center', color: 'white' }}>
          Login Form
        </Typography>
      </TitleBox>
      <InnerContainer>
        <form onSubmit={handleSubmit}>
          <TextField
            variant="outlined"
            margin="normal"
            required
            size="small"
            fullWidth
            id="email"
            label="Email Address"
            placeholder="Enter your email address"
            name="email"
            autoComplete="email"
            autoFocus
            value={formData.email}
            onChange={handleChange}
            error={!!formData.email && !validateEmail(formData.email)}
            helperText={!!formData.email && !validateEmail(formData.email) ? "Please enter a valid email address" : null}
          />
          <TextField
            variant="outlined"
            margin="normal"
            size="small"
            required
            fullWidth
            name="password"
            label="Password"
            placeholder="Enter your password"
            type="password"
            id="password"
            autoComplete="current-password"
            value={formData.password}
            onChange={handleChange}
          />
          <ButtonComponent
            type="submit"
            fullWidth
            style={{marginTop:"30px"}}
            variant="contained"
            color="primary"
          >
            Sign In
          </ButtonComponent>
          <Grid container>
            <Grid item xs mt={3}>
              <Link component={RouterLink} to="/forgot-password" variant="body2">
                Forgot password?
              </Link>
            </Grid>
            <Grid item mt={3}>
              <Link component={RouterLink} to="/signup" variant="body2">
                {"Don't have an account? Sign Up"}
              </Link>
            </Grid>
          </Grid>
        </form>
      </InnerContainer>
      <Modal open={showModal} onClose={closeModal}>
      <Box>
          <OTPInput />
      </Box>
      </Modal>
    </FormContainer>
  );
};

export default Login;
